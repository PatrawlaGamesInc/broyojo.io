### TODOs
| Filename | line # | TODO
|:------|:------:|:------
| server/server.js | 345 | Actually log incorrect passwords.
| client/js/app.js | 96 | Break out into GameControls.
| client/js/chat-client.js | 24 | Break out many of these GameControls into separate classes.